// src/lib/db.ts
// Database client + helper functions for persistence

import { PrismaClient, Prisma } from "@prisma/client";

// ============================================================
// Singleton Prisma client (avoids connection leaks in dev)
// ============================================================
const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined;
};

export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === "development" ? ["error", "warn"] : ["error"],
  });

if (process.env.NODE_ENV !== "production") {
  globalForPrisma.prisma = prisma;
}

// ============================================================
// SESSION HELPERS
// ============================================================

/**
 * Get or create a session for a specific agent + project combination.
 * This is the key function — it ensures conversations persist across visits.
 *
 * If a session exists for this agent+project, returns it.
 * Otherwise creates a new one.
 */
export async function getOrCreateSession(
  agentId: string,
  projectId?: string | null
): Promise<string> {
  // Look for an existing unpinned session for this agent+project
  // (Pinned sessions are intentional conversation threads)
  const existing = await prisma.session.findFirst({
    where: {
      agentId,
      projectId: projectId ?? null,
    },
    orderBy: { lastMessageAt: "desc" },
  });

  if (existing) return existing.id;

  const session = await prisma.session.create({
    data: {
      agentId,
      projectId: projectId ?? null,
    },
  });
  return session.id;
}

/**
 * List all sessions for an agent (for sidebar history)
 */
export async function listSessionsForAgent(agentId: string, limit = 20) {
  return prisma.session.findMany({
    where: { agentId },
    orderBy: { lastMessageAt: "desc" },
    take: limit,
    include: {
      project: true,
      messages: {
        orderBy: { createdAt: "desc" },
        take: 1, // preview of last message
      },
      _count: {
        select: { messages: true },
      },
    },
  });
}

/**
 * Get a full session with all messages for reloading a conversation
 */
export async function getSessionWithMessages(sessionId: string) {
  return prisma.session.findUnique({
    where: { id: sessionId },
    include: {
      project: true,
      messages: {
        orderBy: { createdAt: "asc" },
      },
    },
  });
}

/**
 * Create a new session explicitly (for "New Chat" button)
 */
export async function createNewSession(
  agentId: string,
  projectId?: string | null
) {
  return prisma.session.create({
    data: {
      agentId,
      projectId: projectId ?? null,
    },
  });
}

/**
 * Update session title (usually auto-generated from first user message)
 */
export async function updateSessionTitle(sessionId: string, title: string) {
  return prisma.session.update({
    where: { id: sessionId },
    data: { title: title.slice(0, 100) },
  });
}

/**
 * Pin or unpin a session (prevents auto-reuse, keeps it separate)
 */
export async function toggleSessionPin(sessionId: string) {
  const session = await prisma.session.findUnique({ where: { id: sessionId } });
  if (!session) return null;
  return prisma.session.update({
    where: { id: sessionId },
    data: { isPinned: !session.isPinned },
  });
}

/**
 * Delete a session and all its messages
 */
export async function deleteSession(sessionId: string) {
  return prisma.session.delete({ where: { id: sessionId } });
}

// ============================================================
// MESSAGE HELPERS
// ============================================================

/**
 * Append a message to a session and update the session timestamp
 */
export async function appendMessage(
  sessionId: string,
  role: "user" | "assistant",
  content: string,
  metadata?: Record<string, unknown>
) {
  // Use a transaction to ensure both updates succeed together
  return prisma.$transaction(async (tx) => {
    const message = await tx.message.create({
      data: {
        sessionId,
        role,
        content,
        metadata: metadata ? JSON.stringify(metadata) : null,
      },
    });

    await tx.session.update({
      where: { id: sessionId },
      data: { lastMessageAt: new Date() },
    });

    // Auto-generate session title from first user message if not set
    const session = await tx.session.findUnique({
      where: { id: sessionId },
      select: { title: true },
    });

    if (!session?.title && role === "user") {
      await tx.session.update({
        where: { id: sessionId },
        data: { title: content.slice(0, 80) },
      });
    }

    return message;
  });
}

/**
 * Get the last N messages from a session (for context loading)
 * Returns them in chronological order (oldest first) for API use
 */
export async function getRecentMessages(sessionId: string, limit = 50) {
  const messages = await prisma.message.findMany({
    where: { sessionId },
    orderBy: { createdAt: "desc" },
    take: limit,
  });
  return messages.reverse();
}

/**
 * Convert DB messages to Anthropic API format
 */
export function formatMessagesForApi(
  messages: { role: string; content: string }[]
) {
  return messages.map((m) => ({
    role: m.role as "user" | "assistant",
    content: m.content,
  }));
}

// ============================================================
// PROJECT HELPERS
// ============================================================

export async function listProjects() {
  return prisma.project.findMany({
    where: { status: { not: "archived" } },
    orderBy: { updatedAt: "desc" },
    include: {
      _count: {
        select: { tasks: true, sessions: true },
      },
    },
  });
}

export async function getProjectBySlug(slug: string) {
  return prisma.project.findUnique({
    where: { slug },
    include: { tasks: true },
  });
}

export async function ensureProjectsExist() {
  // Seed the three initial projects if they don't exist
  const seedProjects = [
    {
      slug: "wraptors-saas",
      name: "Wraptors SaaS",
      description: "Vertical SaaS for automotive wrap/PPF/tint shops",
      clientType: "client",
      wikiPage: "projects/wraptors-saas.md",
    },
    {
      slug: "archstudio",
      name: "ArchStudio",
      description: "Custom software for architecture firm",
      clientType: "client",
      wikiPage: "projects/archstudio.md",
    },
    {
      slug: "multi-tenant-platform",
      name: "Multi-Tenant Platform",
      description: "Internal vertical SaaS platform",
      clientType: "internal",
      wikiPage: "projects/multi-tenant-platform.md",
    },
  ];

  for (const p of seedProjects) {
    await prisma.project.upsert({
      where: { slug: p.slug },
      update: {},
      create: p,
    });
  }
}

// ============================================================
// TASK HELPERS
// ============================================================

export async function createTask(data: {
  title: string;
  description?: string;
  projectId?: string;
  agentId?: string;
  priority?: string;
  parentTaskId?: string;
  orchestrationId?: string;
}) {
  return prisma.task.create({ data });
}

export async function updateTaskStatus(
  taskId: string,
  status: "queued" | "in_progress" | "blocked" | "done" | "cancelled"
) {
  return prisma.task.update({
    where: { id: taskId },
    data: {
      status,
      completedAt: status === "done" ? new Date() : null,
    },
  });
}

export async function listTasksByProject(projectId: string) {
  return prisma.task.findMany({
    where: { projectId },
    orderBy: { updatedAt: "desc" },
  });
}

// ============================================================
// ORCHESTRATION HELPERS
// ============================================================

export async function createOrchestration(data: {
  userPrompt: string;
  projectId?: string;
}) {
  return prisma.orchestration.create({ data });
}

export async function completeOrchestration(id: string, summary: string) {
  return prisma.orchestration.update({
    where: { id },
    data: {
      status: "completed",
      summary,
      completedAt: new Date(),
    },
  });
}

// ============================================================
// AGENT ACTIVITY (live feed)
// ============================================================

export async function logActivity(data: {
  agentId: string;
  activityType: string;
  content: string;
  orchestrationId?: string;
  taskId?: string;
}) {
  return prisma.agentActivity.create({ data });
}

export async function getRecentActivity(limit = 50) {
  return prisma.agentActivity.findMany({
    orderBy: { timestamp: "desc" },
    take: limit,
  });
}
