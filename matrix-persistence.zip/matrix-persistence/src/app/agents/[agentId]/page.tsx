// src/app/agents/[agentId]/page.tsx
// Agent chat page with persistent conversations

"use client";

import { use, useState, useRef, useEffect } from "react";
import { useAgentSession, useSessionHistory } from "@/hooks/useSession";
import { AGENT_CONFIGS, AgentId } from "@/config/agents";
import ReactMarkdown from "react-markdown";

interface PageProps {
  params: Promise<{ agentId: string }>;
}

export default function AgentChatPage({ params }: PageProps) {
  const { agentId } = use(params);
  const agent = AGENT_CONFIGS[agentId as AgentId];

  const [selectedProject, setSelectedProject] = useState<string>("all");
  const [input, setInput] = useState("");
  const [showHistory, setShowHistory] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Map project selection to the projectId for session scoping
  const projectId = selectedProject === "all" ? null : selectedProject;

  const {
    messages,
    loading,
    sending,
    error,
    sendMessage,
    startNewSession,
  } = useAgentSession(agentId, projectId);

  const { sessions } = useSessionHistory(agentId);

  // Auto-scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  if (!agent) {
    return <div className="p-8">Agent not found</div>;
  }

  const handleSend = () => {
    if (!input.trim()) return;

    const selectedProjects =
      selectedProject === "all"
        ? ["wraptors-saas", "archstudio", "multi-tenant-platform"]
        : [selectedProject];

    sendMessage(input, selectedProjects);
    setInput("");
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="flex h-screen">
      {/* History sidebar (toggleable) */}
      {showHistory && (
        <aside className="w-72 border-r border-neutral-800 bg-neutral-950 p-4 overflow-y-auto">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-neutral-400">
              Conversation History
            </h3>
            <button
              onClick={startNewSession}
              className="text-xs px-2 py-1 bg-neutral-800 hover:bg-neutral-700 rounded"
              title="Start new conversation"
            >
              + New
            </button>
          </div>
          <div className="space-y-1">
            {sessions.length === 0 && (
              <p className="text-xs text-neutral-500">No conversations yet</p>
            )}
            {sessions.map((s) => (
              <button
                key={s.id}
                className="block w-full text-left px-3 py-2 rounded hover:bg-neutral-800 text-sm"
              >
                <div className="truncate font-medium text-neutral-200">
                  {s.title || "Untitled conversation"}
                </div>
                <div className="text-xs text-neutral-500 mt-1">
                  {new Date(s.lastMessageAt).toLocaleDateString()}
                </div>
              </button>
            ))}
          </div>
        </aside>
      )}

      {/* Main chat area */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <header className="border-b border-neutral-800 p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="text-3xl">{agent.avatar}</span>
            <div>
              <h1 className="font-semibold text-lg">{agent.name}</h1>
              <p className="text-sm text-neutral-400">{agent.title}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <select
              value={selectedProject}
              onChange={(e) => setSelectedProject(e.target.value)}
              className="bg-neutral-800 border border-neutral-700 rounded px-3 py-1.5 text-sm"
            >
              <option value="all">All Projects</option>
              <option value="wraptors-saas">Wraptors SaaS</option>
              <option value="archstudio">ArchStudio</option>
              <option value="multi-tenant-platform">Multi-Tenant Platform</option>
            </select>

            <button
              onClick={() => setShowHistory(!showHistory)}
              className="px-3 py-1.5 text-sm bg-neutral-800 hover:bg-neutral-700 rounded"
            >
              {showHistory ? "Hide" : "History"}
            </button>

            <button
              onClick={startNewSession}
              className="px-3 py-1.5 text-sm bg-neutral-800 hover:bg-neutral-700 rounded"
            >
              New Chat
            </button>
          </div>
        </header>

        {/* Messages area */}
        <main className="flex-1 overflow-y-auto">
          <div className="max-w-3xl mx-auto px-6 py-8">
            {loading && (
              <div className="text-center text-neutral-500 py-8">
                Loading conversation...
              </div>
            )}

            {!loading && messages.length === 0 && (
              <div className="text-center text-neutral-500 py-16">
                <div className="text-5xl mb-4">{agent.avatar}</div>
                <p className="text-lg mb-2">Start a conversation with {agent.name}</p>
                <p className="text-sm">{agent.description}</p>
              </div>
            )}

            <div className="space-y-6">
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex ${
                    msg.role === "user" ? "justify-end" : "justify-start"
                  }`}
                >
                  <div
                    className={`max-w-[85%] rounded-lg px-5 py-3 ${
                      msg.role === "user"
                        ? "bg-blue-600 text-white"
                        : "bg-neutral-900 border border-neutral-800"
                    }`}
                  >
                    {msg.role === "assistant" ? (
                      <div className="prose prose-invert prose-sm max-w-none">
                        <ReactMarkdown>{msg.content}</ReactMarkdown>
                      </div>
                    ) : (
                      <p className="whitespace-pre-wrap">{msg.content}</p>
                    )}
                  </div>
                </div>
              ))}

              {sending && (
                <div className="flex justify-start">
                  <div className="bg-neutral-900 border border-neutral-800 rounded-lg px-5 py-3">
                    <div className="flex gap-1">
                      <div className="w-2 h-2 bg-neutral-500 rounded-full animate-pulse" />
                      <div className="w-2 h-2 bg-neutral-500 rounded-full animate-pulse delay-75" />
                      <div className="w-2 h-2 bg-neutral-500 rounded-full animate-pulse delay-150" />
                    </div>
                  </div>
                </div>
              )}

              {error && (
                <div className="bg-red-900/30 border border-red-800 rounded-lg px-4 py-3 text-red-200 text-sm">
                  Error: {error}
                </div>
              )}
            </div>

            <div ref={messagesEndRef} />
          </div>
        </main>

        {/* Input */}
        <footer className="border-t border-neutral-800 p-4">
          <div className="max-w-3xl mx-auto">
            <div className="flex gap-2">
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={`Message ${agent.name}...`}
                rows={1}
                className="flex-1 bg-neutral-900 border border-neutral-800 rounded-lg px-4 py-3 resize-none focus:outline-none focus:border-neutral-600"
                disabled={sending}
              />
              <button
                onClick={handleSend}
                disabled={!input.trim() || sending}
                className="px-6 py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-neutral-800 disabled:text-neutral-500 rounded-lg font-medium"
              >
                Send
              </button>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}
