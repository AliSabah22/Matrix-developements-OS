// src/app/api/sessions/route.ts
// List sessions for an agent (used by the sidebar history)

import { NextRequest, NextResponse } from "next/server";
import { listSessionsForAgent, createNewSession } from "@/lib/db";

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const agentId = searchParams.get("agentId");

  if (!agentId) {
    return NextResponse.json({ error: "agentId required" }, { status: 400 });
  }

  const sessions = await listSessionsForAgent(agentId);
  return NextResponse.json({ sessions });
}

export async function POST(request: NextRequest) {
  const body = await request.json();
  const { agentId, projectId } = body;

  if (!agentId) {
    return NextResponse.json({ error: "agentId required" }, { status: 400 });
  }

  const session = await createNewSession(agentId, projectId);
  return NextResponse.json({ session });
}
