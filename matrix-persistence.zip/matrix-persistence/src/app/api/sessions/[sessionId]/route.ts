// src/app/api/sessions/[sessionId]/route.ts
// Load a full session with all messages (for reloading conversations)

import { NextRequest, NextResponse } from "next/server";
import {
  getSessionWithMessages,
  deleteSession,
  toggleSessionPin,
  updateSessionTitle,
} from "@/lib/db";

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ sessionId: string }> }
) {
  const { sessionId } = await params;
  const session = await getSessionWithMessages(sessionId);

  if (!session) {
    return NextResponse.json({ error: "Session not found" }, { status: 404 });
  }

  return NextResponse.json({ session });
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ sessionId: string }> }
) {
  const { sessionId } = await params;
  const body = await request.json();

  if (body.action === "pin") {
    const session = await toggleSessionPin(sessionId);
    return NextResponse.json({ session });
  }

  if (body.title) {
    const session = await updateSessionTitle(sessionId, body.title);
    return NextResponse.json({ session });
  }

  return NextResponse.json({ error: "Invalid action" }, { status: 400 });
}

export async function DELETE(
  _request: NextRequest,
  { params }: { params: Promise<{ sessionId: string }> }
) {
  const { sessionId } = await params;
  await deleteSession(sessionId);
  return NextResponse.json({ success: true });
}
