// src/app/api/chat/route.ts
// Chat endpoint with full conversation persistence
// Every message is saved, sessions persist across visits

import { NextRequest, NextResponse } from "next/server";
import { buildSystemPrompt, getMcpServers } from "@/lib/prompt-builder";
import { AgentId } from "@/config/agents";
import {
  getOrCreateSession,
  appendMessage,
  getRecentMessages,
  formatMessagesForApi,
  logActivity,
} from "@/lib/db";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      agentId,
      userMessage,
      selectedProjects,
      sessionId: providedSessionId, // optional — if not provided, we find or create one
      projectId, // optional — for project association
    }: {
      agentId: AgentId;
      userMessage: string;
      selectedProjects?: string[];
      sessionId?: string;
      projectId?: string;
    } = body;

    // 1. Get or create the persistent session for this agent+project
    const sessionId =
      providedSessionId ??
      (await getOrCreateSession(agentId, projectId ?? null));

    // 2. Save the user's message immediately
    await appendMessage(sessionId, "user", userMessage);

    // 3. Load recent conversation history from DB (for context)
    const history = await getRecentMessages(sessionId, 50);
    const apiMessages = formatMessagesForApi(history);

    // 4. Log activity
    await logActivity({
      agentId,
      activityType: "started",
      content: `Processing message in session ${sessionId}`,
    });

    // 5. Build system prompt from vault
    const systemPrompt = await buildSystemPrompt({
      agentId,
      selectedProjects,
    });

    // 6. Get MCP servers for this agent
    const mcpServers = getMcpServers(agentId);

    // 7. Call Claude API
    const apiBody: Record<string, unknown> = {
      model: "claude-sonnet-4-20250514",
      max_tokens: 4096,
      system: systemPrompt,
      messages: apiMessages,
    };

    if (mcpServers.length > 0) {
      apiBody.mcp_servers = mcpServers;
    }

    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY!,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify(apiBody),
    });

    if (!response.ok) {
      const error = await response.text();
      console.error("Claude API error:", error);
      await logActivity({
        agentId,
        activityType: "error",
        content: `API error: ${error.slice(0, 200)}`,
      });
      return NextResponse.json(
        { error: "Failed to get response from Claude", details: error },
        { status: response.status }
      );
    }

    const data = await response.json();

    // 8. Extract assistant response
    const assistantContent = data.content
      .filter((block: { type: string }) => block.type === "text")
      .map((block: { text: string }) => block.text)
      .join("\n");

    // 9. Save the assistant's response to DB
    await appendMessage(sessionId, "assistant", assistantContent, {
      model: data.model,
      usage: data.usage,
    });

    // 10. Log completion
    await logActivity({
      agentId,
      activityType: "completed",
      content: `Responded in session ${sessionId}`,
    });

    // 11. Return response with sessionId so the client can reuse it
    return NextResponse.json({
      sessionId,
      response: assistantContent,
      model: data.model,
      usage: data.usage,
    });
  } catch (error) {
    console.error("Chat API error:", error);
    return NextResponse.json(
      { error: "Internal server error", details: String(error) },
      { status: 500 }
    );
  }
}
