// src/hooks/useSession.ts
// React hook for managing persistent conversations with agents

import { useState, useEffect, useCallback } from "react";

export interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  createdAt: string;
}

export interface Session {
  id: string;
  agentId: string;
  projectId: string | null;
  title: string | null;
  isPinned: boolean;
  createdAt: string;
  lastMessageAt: string;
  messages?: Message[];
}

/**
 * Main hook for an agent chat page.
 * Handles: loading existing session on mount, sending messages, managing history.
 */
export function useAgentSession(agentId: string, projectId?: string | null) {
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Load the persistent session for this agent+project on mount
  // This is what fixes the "nothing shows up when I come back" problem
  useEffect(() => {
    const loadLatestSession = async () => {
      setLoading(true);
      try {
        // Get all sessions for this agent
        const res = await fetch(`/api/sessions?agentId=${agentId}`);
        const data = await res.json();

        // Find the most recent session that matches the current project scope
        const matching = data.sessions?.find(
          (s: Session) => s.projectId === (projectId ?? null)
        );

        if (matching) {
          // Load the full conversation
          const fullRes = await fetch(`/api/sessions/${matching.id}`);
          const fullData = await fullRes.json();
          setSessionId(matching.id);
          setMessages(fullData.session?.messages ?? []);
        } else {
          // No existing session — will be created on first message
          setSessionId(null);
          setMessages([]);
        }
      } catch (err) {
        setError(String(err));
      } finally {
        setLoading(false);
      }
    };

    loadLatestSession();
  }, [agentId, projectId]);

  // Send a message to the agent
  const sendMessage = useCallback(
    async (userMessage: string, selectedProjects?: string[]) => {
      if (!userMessage.trim() || sending) return;

      setSending(true);
      setError(null);

      // Optimistically add the user message
      const optimisticMessage: Message = {
        id: `temp-${Date.now()}`,
        role: "user",
        content: userMessage,
        createdAt: new Date().toISOString(),
      };
      setMessages((prev) => [...prev, optimisticMessage]);

      try {
        const res = await fetch("/api/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            agentId,
            userMessage,
            selectedProjects,
            sessionId, // pass existing session if we have one
            projectId,
          }),
        });

        if (!res.ok) {
          const err = await res.json();
          throw new Error(err.error || "Failed to send message");
        }

        const data = await res.json();

        // Update sessionId if this was a new session
        if (data.sessionId && !sessionId) {
          setSessionId(data.sessionId);
        }

        // Add the assistant's response
        const assistantMessage: Message = {
          id: `msg-${Date.now()}`,
          role: "assistant",
          content: data.response,
          createdAt: new Date().toISOString(),
        };
        setMessages((prev) => [...prev, assistantMessage]);
      } catch (err) {
        setError(String(err));
        // Remove the optimistic message on error
        setMessages((prev) => prev.filter((m) => m.id !== optimisticMessage.id));
      } finally {
        setSending(false);
      }
    },
    [agentId, projectId, sessionId, sending]
  );

  // Start a fresh conversation (doesn't delete the old one)
  const startNewSession = useCallback(async () => {
    try {
      const res = await fetch("/api/sessions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ agentId, projectId }),
      });
      const data = await res.json();
      setSessionId(data.session.id);
      setMessages([]);
    } catch (err) {
      setError(String(err));
    }
  }, [agentId, projectId]);

  return {
    sessionId,
    messages,
    loading,
    sending,
    error,
    sendMessage,
    startNewSession,
  };
}

/**
 * Hook for listing all sessions for an agent (for the history sidebar)
 */
export function useSessionHistory(agentId: string) {
  const [sessions, setSessions] = useState<Session[]>([]);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/sessions?agentId=${agentId}`);
      const data = await res.json();
      setSessions(data.sessions ?? []);
    } finally {
      setLoading(false);
    }
  }, [agentId]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  return { sessions, loading, refresh };
}
